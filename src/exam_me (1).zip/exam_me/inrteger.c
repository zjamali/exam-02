#include <math.h>

int main()
{
	int a = pow(2, 32);
	a /= 2;
	printf("%d", a);
}
