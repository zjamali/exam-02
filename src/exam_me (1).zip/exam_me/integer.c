
#include <math.h>
int main()
{
    double a;
    a = pow(2, 32) / 2;
    printf("%f", a);
}